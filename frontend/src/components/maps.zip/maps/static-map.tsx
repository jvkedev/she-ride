"use client";
import "leaflet/dist/leaflet.css";
import { useEffect, useRef, useState } from "react";
import { MapContainer, Marker, Popup, TileLayer, useMap } from "react-leaflet";
import L from "leaflet";
import MapController from "@/components/maps/map-controller";
import MapZoomControls from "@/components/maps/map-zoom-controls";

const DEFAULT: [number, number] = [28.6139, 77.209];

const RiderIcon = new L.Icon({
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

function isValidCoords(coords: [number, number]) {
  return (
    Array.isArray(coords) &&
    coords.length === 2 &&
    Number.isFinite(coords[0]) &&
    Number.isFinite(coords[1])
  );
}

function MapUpdater({ position }: { position: [number, number] }) {
  const map = useMap();
  const hasFlown = useRef(false);

  useEffect(() => {
    const [lat, lng] = position;
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;
    if (lat === DEFAULT[0] && lng === DEFAULT[1]) return;

    if (!hasFlown.current) {
      map.flyTo([lat, lng], 15, { animate: true, duration: 1 });
      hasFlown.current = true;
    } else {
      map.panTo([lat, lng], { animate: true });
    }
  }, [position, map]);

  return null;
}

export default function StaticMap() {
  const [position, setPosition] = useState<[number, number]>(DEFAULT);
  const watchId = useRef<number | null>(null);

  useEffect(() => {
    if (!navigator.geolocation) return;

    watchId.current = navigator.geolocation.watchPosition(
      (pos) => {
        const lat = Number(pos.coords.latitude);
        const lng = Number(pos.coords.longitude);
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;
        setPosition([lat, lng]);
      },
      (err) => console.error("GPS error:", err),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 5000 },
    );

    return () => {
      if (watchId.current !== null)
        navigator.geolocation.clearWatch(watchId.current);
    };
  }, []);

  const safePosition = isValidCoords(position) ? position : DEFAULT;

  return (
    <MapContainer
      center={DEFAULT}
      zoom={13}
      className="h-full w-full rounded-2xl"
      style={{ height: "100%", width: "100%", minHeight: 320 }}
      dragging
      touchZoom
      scrollWheelZoom
      doubleClickZoom
      zoomControl={false}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <Marker position={safePosition} icon={RiderIcon}>
        <Popup>Your location</Popup>
      </Marker>
      <MapUpdater position={safePosition} />
      <MapController />
      <MapZoomControls />
    </MapContainer>
  );
}
