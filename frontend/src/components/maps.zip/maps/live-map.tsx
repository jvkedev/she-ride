"use client";

import "leaflet/dist/leaflet.css";

import { useEffect, useRef, useState } from "react";
import { MapContainer, Marker, Popup, TileLayer, useMap } from "react-leaflet";

import L from "leaflet";

import MapController from "@/components/maps/map-controller";
import MapZoomControls from "@/components/maps/map-zoom-controls";

import {
  connectSocket,
  disconnectSocket,
  sendCaptainLocation,
} from "@/services/socket/socket.service";

import { useCaptainStore } from "@/store/captain.store";

const MarkerIcon = new L.Icon({
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

const DEFAULT: [number, number] = [28.6139, 77.209];

function isValidCoords(coords: [number, number]) {
  return (
    Array.isArray(coords) &&
    coords.length === 2 &&
    Number.isFinite(coords[0]) &&
    Number.isFinite(coords[1])
  );
}

function MapUpdater({ position }: { position: [number, number] }) {
  const map = useMap();
  const hasFlown = useRef(false);

  useEffect(() => {
    const [lat, lng] = position;
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      console.error("Invalid map position:", position);
      return;
    }

    if (!hasFlown.current) {
      map.flyTo([lat, lng], 15, {
        animate: true,
        duration: 1,
      });

      hasFlown.current = true;
      return;
    }

    map.panTo([lat, lng], {
      animate: true,
    });
  }, [position, map]);

  return null;
}

interface LiveMapProps {
  rideId?: string;
}

export default function LiveMap({ rideId }: LiveMapProps) {
  const { activeRideId } = useCaptainStore();

  const [position, setPosition] = useState<[number, number]>(DEFAULT);

  const watchId = useRef<number | null>(null);

  const intervalId = useRef<ReturnType<typeof setInterval> | null>(null);

  const latestPos = useRef<[number, number]>(DEFAULT);

  const rideIdRef = useRef<string | undefined>(
    rideId ?? activeRideId ?? undefined,
  );

  const userIdRef = useRef<string | null>(null);

  // Sync latest ride id
  useEffect(() => {
    rideIdRef.current = rideId ?? activeRideId ?? undefined;
  }, [rideId, activeRideId]);

  useEffect(() => {
    const token = localStorage.getItem("accessToken");

    if (!token) return;

    try {
      const payload = JSON.parse(atob(token.split(".")[1]));

      if (payload.role !== "CAPTAIN") {
        return;
      }

      userIdRef.current = payload.sub;

      connectSocket(payload.sub);

      if (!navigator.geolocation) {
        console.error("Geolocation not supported");
        return;
      }

      watchId.current = navigator.geolocation.watchPosition(
        (pos) => {
          const lat = Number(pos.coords.latitude);

          const lng = Number(pos.coords.longitude);

          if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
            console.error("Invalid GPS coords:", lat, lng);

            return;
          }

          const coords: [number, number] = [lat, lng];

          console.log("Updated location:", coords);

          setPosition(coords);

          latestPos.current = coords;
        },

        (err) => {
          console.error("GPS error:", err);
        },

        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 5000,
        },
      );

      intervalId.current = setInterval(() => {
        const [lat, lng] = latestPos.current;

        const currentRideId = rideIdRef.current;

        const userId = userIdRef.current;

        if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
          console.error("Invalid location before socket emit:", lat, lng);

          return;
        }

        if (currentRideId && userId) {
          console.log("Sending captain location:", {
            rideId: currentRideId,
            userId,
            lat,
            lng,
          });

          sendCaptainLocation(currentRideId, userId, lat, lng);
        }
      }, 3000);
    } catch (error) {
      console.error("Token parse error:", error);
    }

    return () => {
      if (watchId.current !== null) {
        navigator.geolocation.clearWatch(watchId.current);
      }

      if (intervalId.current !== null) {
        clearInterval(intervalId.current);
      }

      disconnectSocket();
    };
  }, []);

  const safePosition = isValidCoords(position) ? position : DEFAULT;

  return (
    <MapContainer
      center={safePosition}
      zoom={15}
      className="h-full w-full rounded-2xl"
      style={{
        height: "100%",
        width: "100%",
        minHeight: 320,
      }}
      dragging
      touchZoom
      scrollWheelZoom
      doubleClickZoom
      zoomControl={false}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />

      {isValidCoords(safePosition) && (
        <Marker position={safePosition} icon={MarkerIcon}>
          <Popup>Your location</Popup>
        </Marker>
      )}

      <MapUpdater position={safePosition} />

      <MapController />

      <MapZoomControls />
    </MapContainer>
  );
}
